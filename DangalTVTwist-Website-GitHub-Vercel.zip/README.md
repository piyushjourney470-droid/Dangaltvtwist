# Dangal TV Twist — static website

This repository is a static HTML migration prototype generated from the Blogger Takeout backup.

## Contents
- `30` live Blogger posts converted to individual HTML pages
- `4` live information/legal pages
- Responsive Hindi-first homepage with client-side text and category filtering
- `sitemap.xml`, `robots.txt`, and Vercel static hosting configuration

## Deploy on Vercel
1. Import this GitHub repository into Vercel.
2. Select **Other** / static HTML if prompted.
3. Leave build command empty; serve the repository root as the output.
4. After the first deploy, verify the assigned domain. This package currently assumes `https://dangaltvtwistt.vercel.app`; if Vercel assigns a different domain, update canonical URL tags in every HTML file and the URLs in `sitemap.xml` and `robots.txt` before sending the sitemap to search engines.

## Important migration notes
- Blogger remains the source site; do not delete it before testing this deployment.
- Post images currently use their hosted Blogger image URLs, so the site is small and does not upload the large Takeout photo archive to GitHub.
- Blogger comments, Blogger widgets, ads, and live feed behavior are not a part of this static migration.
- The supplied theme XML contained an obfuscated external script loader. It was not copied into this website.
- Only entries marked `LIVE` in the Takeout `feed.atom` were published here; `SOFT_TRASHED` entries were excluded.
- Some YouTube embeds are retained only when the embed URL uses YouTube's embed domains; other iframes and active scripts are removed.

## Custom domain
Keep the original Blogger URL online while validating all important post URLs. Configure any custom domain only after deciding the canonical destination and redirect plan.

## Upload from Android
1. Download the ZIP and extract it using your phone's Files app.
2. In GitHub, open `piyushjourney470-droid/Dangaltvtwistt` and use **Add file → Upload files**.
3. Upload the project files (not the ZIP itself). Preserve the `assets/` and `posts/` folder paths. If GitHub's mobile file picker cannot upload folders with their paths, use GitHub's **Create new file** flow for the `assets/` and `posts/` paths or upload from a desktop browser.
4. Commit the files to `main`. Then import the repository in Vercel.
